import '../scss/module.scss';

require('expose?OnBoarding!./src/OnBoarding.js');
